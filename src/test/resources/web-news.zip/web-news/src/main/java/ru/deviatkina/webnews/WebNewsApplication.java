package ru.deviatkina.webnews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebNewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebNewsApplication.class, args);
	}

}
